# Challenge-1
este repositorio tiene como fin presentar mi proyecto para  challenge #1 encriptador de texto del programa ONE next educación en alianza con Alula Latam 

en este proyecto se realizo un encriptador de texto que funciona con dos botones , el usuario pone el texto que se quiere encriptar y al pulsar el boton segun condiciones para encriptar  o al contrario si se tiene una palabra o frase encriptada el boton desencriptar hara el trabajo.
Por ejemplo:
"gato" => "gaitober"
gaitober" => "gato"

se utiliza un diseño llamativo y visual con el fin de llamar la atencion de los usuarios